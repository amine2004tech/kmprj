#include <stdio.h>
#include <stdlib.h>

typedef int Element ;
typedef struct noeud
{
    Element valeur ;
    struct noeud *filsG ;
    struct noeud *filsD ;
} noeud;

typedef noeud* arbreB ;

arbreB arbreBVide()
{
    return NULL;
}

int testerArbreBVide(arbreB a)
{
    return a==NULL;
}

arbreB creeNoeud(Element val, arbreB fg, arbreB fd)
{
    arbreB a=(arbreB)malloc (sizeof(noeud )) ;
    a->valeur=val ;
    a->filsG=fg ;
    a->filsD=fd ;
    return a ;
}

arbreB filsGauche(arbreB a)
{
    if (testerArbreBVide(a))
        return NULL;
    return a->filsG ;
}

arbreB filsDroit(arbreB a)
{
    if (testerArbreBVide(a))
        return NULL;
    return a->filsD ;
}

arbreB ajouterGElementArbreB( arbreB a, Element val )
{
    if(testerArbreBVide(a))
        a=creeNoeud(val,NULL,NULL) ;
    else if(filsGauche(a)==NULL)
        a->filsG=creeNoeud(val,NULL,NULL) ;
    else if(filsDroit(a)==NULL)
        a->filsD=creeNoeud(val,NULL,NULL) ;
    else
        a->filsG=ajouterGElementArbreB(filsGauche(a), val) ;
    return a ;
}


void AfficherArbre(arbreB root, int niveau)
{
    //Tester si l'arbre est vide
    if(root == NULL)
    {
        return;
    }
    //Afficher la valeur du noeud courant
    for(int i = 0; i <= niveau; i++)
    {
        if(niveau - i > 1)
        {
            printf("  ");
        }
        else if (niveau - i == 1)
        {
            printf("|-");
        }
        else if (niveau - i == 0)
        {
            printf("%d", root->valeur);
        }
    }
    printf("\n");

    AfficherArbre(root->filsG, niveau + 1);

    AfficherArbre(root->filsD, niveau + 1);
}


int main()
{
    arbreB A = arbreBVide();

    //Arbre Binaire Gauche
    A = ajouterGElementArbreB(A, 20);
    A = ajouterGElementArbreB(A, 5);
    A = ajouterGElementArbreB(A, 12);
    A = ajouterGElementArbreB(A, 3);
    A = ajouterGElementArbreB(A, 25);
    A = ajouterGElementArbreB(A, 28);
    A = ajouterGElementArbreB(A, 21);
    A = ajouterGElementArbreB(A, 13);
    A = ajouterGElementArbreB(A, 8);
    A = ajouterGElementArbreB(A, 6);

    AfficherArbre(A, 0);

    return 0;
}
